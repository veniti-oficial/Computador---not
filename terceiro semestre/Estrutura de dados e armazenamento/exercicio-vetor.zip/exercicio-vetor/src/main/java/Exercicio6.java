import java.util.Scanner;

public class Exercicio6 {
    public static void main(String[] args) {
        Integer[] vetor = new Integer[365];
        Scanner leitor = new Scanner(System.in);

        System.out.println("Digite um dia do mês");
        Integer dia = leitor.nextInt();

        System.out.println("Digite um mês");
        Integer mês  = leitor.nextInt();
        
    }
}
