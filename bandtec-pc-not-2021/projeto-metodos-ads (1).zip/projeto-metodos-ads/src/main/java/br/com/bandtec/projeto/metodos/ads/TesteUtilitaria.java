package br.com.bandtec.projeto.metodos.ads;

public class TesteUtilitaria {

    public static void main(String[] args) {

        Utilitaria util = new Utilitaria();

//        System.out.println("---------------------");
//        util.exibirLinha();
//        System.out.println(String.format("Nome: %s", "Diego"));
//        util.exibirNome();
//        util.exibirNomeDecorado();
//        util.exibirLinha();
//        System.out.println("---------------------");
        
//        String x = "Diego";
//
//        util.exibirNome(x);
//        
//        util.exibirNome("Giuliana");

        util.exibirNomeDecorado("Diego");
    }
}
