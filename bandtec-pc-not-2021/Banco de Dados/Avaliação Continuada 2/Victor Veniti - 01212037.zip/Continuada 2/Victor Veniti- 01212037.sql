create database jornal;
use jornal;

create table telejornal(
idTelejornal int primary key auto_increment,
nome varchar(45),
horario datetime default current_timestamp
)auto_increment = 100;

create table jornalista(
idJornalista int primary key auto_increment,
nome varchar(45),
salario varchar(15),
tipo varchar(45)
)auto_increment = 20;


insert into telejornal values
(null,'globo', default),
(null,'band', default),
(null,'rede tv', default),
(null,'sbt', default),
(null,'record', default);

insert into jornalista values
(null, 'priscilla Soares', 5500, 'Âncora'),
(null, 'Janilton Monteiro', 4400, 'Repórter'),
(null, 'Alexandre Laerte', 5000, 'Âncora'),
(null, 'Janaina Cabral', 6300, 'Repórter'),
(null, 'Alordia Curci', 7200, 'Âncora'),
(null, 'Luiz Fogal', 6300, 'Repórter');

-- Exibir todos os dados de cada tabela criada, separadamente.
select*from telejornal;
select*from jornalista;

-- Fazer os acertos da chave estrangeira, caso não tenha feito no momento da criação.
alter table jornalista add Fktelejornal int;
alter table jornalista add foreign key jornalista(Fktelejornal) references telejornal(idTelejornal);

update jornalista set Fktelejornal = '100' where idJornalista = '25';
update jornalista set Fktelejornal = '101' where idJornalista = '20';
update jornalista set Fktelejornal = '102' where idJornalista = '21';
update jornalista set Fktelejornal = '103' where idJornalista = '22';
update jornalista set Fktelejornal = '104' where idJornalista = '23';
update jornalista set Fktelejornal = '104' where idJornalista = '24';

-- Exibir os dados dos telejornais e os dados de seus respectivos jornalistas.
select*from telejornal join jornalista on Fktelejornal = idTelejornal;

-- Exibir os dados de um determinado telejornal (informar o nome do telejornal na consulta) e os dados de seus respectivos jornalistas.
select*from telejornal join jornalista on Fktelejornal = idTelejornal where telejornal.nome = 'record';

-- Exibir apenas o nome do telejornal e o nome do seu respectivo jornalista.
select telejornal.nome as 'nome telejornal', jornalista.nome as 'nome jornalista' from telejornal join jornalista on Fktelejornal = idTelejornal;

-- Atualizar o jornalista de um determinado telejornal.
update jornalista set jornalista.nome = 'lilian oliveira' where Idjornalista = '24';

-- Atualizar o salário de um determinado jornalista.
update jornalista set salario = '5000' where idJornalista = '21';

-- Deletar um determinado jornalista ou um determinado telejornal.
delete from jornalista where idJornalista = '22';

-- Utilizar pelo menos 2 funções matemáticas utilizando o campo salario (MAX, MIN, COUNT, AVG, SUM, GROUP BY).
select MAX(salario) from jornalista;

-- Utilizar pelo menos 2 funções matemáticas utilizando o campo salario (MAX, MIN, COUNT, AVG, SUM, GROUP BY).
select truncate(avg(salario),2) from jornalista;







