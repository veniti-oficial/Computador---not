package school.sptech.projeto1.heranca;

public class ProdutoInternacional {
 
    /* 
        Essa classe deve ser herdeira de produto;
        O método "getPreco" (getter padrão) deverá ser sobreescrito e possuir um acréscimo de 
        60%;
    */   
        
    
}
