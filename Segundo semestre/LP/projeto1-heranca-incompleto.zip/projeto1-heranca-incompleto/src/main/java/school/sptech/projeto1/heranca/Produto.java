package school.sptech.projeto1.heranca;

public class Produto {
    
    private Integer id;
    private String nome;
    private String categoria;
    private Double preco;
    
    public Produto(Integer id, String nome, String categoria, Double preco) {
        this.id = id;
        this.nome = nome;
        this.categoria = categoria;
        this.preco = preco;
    }
}
